package com.example.kafkaexample;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component

public class kafkalisterner {
//
//    @KafkaListener(topics = "pratice" ,groupId = "groupid")
//    public void listerner(String data){
//        System.out.println("Listerner data :::: " + data);
//    }

}
